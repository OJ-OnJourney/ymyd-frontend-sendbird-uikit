var INIT_USER = 'INIT_USER';
var RESET_USER = 'RESET_USER';
var UPDATE_USER_INFO = 'UPDATE_USER_INFO';

export { INIT_USER as I, RESET_USER as R, UPDATE_USER_INFO as U };
//# sourceMappingURL=actionTypes-a85c0eaa.js.map
