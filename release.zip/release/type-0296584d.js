var MessageStatusType = {
  PENDING: 'PENDING',
  SENT: 'SENT',
  DELIVERED: 'DELIVERED',
  READ: 'READ',
  FAILED: 'FAILED'
};

export { MessageStatusType as M };
//# sourceMappingURL=type-0296584d.js.map
